// next.config.js

module.exports = {
    images: {
      domains: ['localhost'], // Add 'localhost' to allow images from this domain
    },
  };
  
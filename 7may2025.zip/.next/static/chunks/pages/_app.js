__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_d1cd69cb._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_@apollo_client_dcf859fe._.js",
  "static/chunks/node_modules_graphql_931a79b8._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_73949438._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e3f._.js",
  "static/chunks/node_modules_react-icons_lib_75a63dfe._.js",
  "static/chunks/node_modules_5ae04d65._.js",
  "static/chunks/[root-of-the-server]__bb70161c._.js",
  "static/chunks/styles_globals_79636149.css",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_083a618c._.js"
])

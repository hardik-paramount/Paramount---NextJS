__turbopack_load_page_chunks__("/blog/[...slug]", [
  "static/chunks/node_modules_next_e58d2b78._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_graphql_332245bf._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e3f._.js",
  "static/chunks/node_modules_react-icons_lib_75a63dfe._.js",
  "static/chunks/node_modules_715de813._.js",
  "static/chunks/[root-of-the-server]__875c0d8f._.js",
  "static/chunks/styles_globals_79636149.css",
  "static/chunks/pages_blog_[___slug]_5771e187.js",
  "static/chunks/pages_blog_[___slug]_160f0b0f.js"
])

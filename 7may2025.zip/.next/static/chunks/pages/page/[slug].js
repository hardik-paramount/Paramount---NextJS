__turbopack_load_page_chunks__("/page/[slug]", [
  "static/chunks/node_modules_next_dist_f1d2d383._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__fee15914._.js",
  "static/chunks/pages_page_[slug]_5771e187.js",
  "static/chunks/pages_page_[slug]_087cd027.js"
])

__turbopack_load_page_chunks__("/category/[slug]", [
  "static/chunks/node_modules_next_7819c29e._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__124a0fa7._.js",
  "static/chunks/pages_category_[slug]_5771e187.js",
  "static/chunks/pages_category_[slug]_dfe6a49d.js"
])

__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_e58d2b78._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_@apollo_client_dcf859fe._.js",
  "static/chunks/node_modules_graphql_931a79b8._.js",
  "static/chunks/node_modules_5ae04d65._.js",
  "static/chunks/[root-of-the-server]__955e8fe4._.js",
  "static/chunks/pages_index_5771e187._.js",
  "static/chunks/pages_index_c59dd926._.js"
])

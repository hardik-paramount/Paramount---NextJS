(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_globals_73c37791.css",
  "static/chunks/node_modules_@apollo_client_1545b0fd._.js",
  "static/chunks/node_modules_graphql_d18cfce9._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_ad81a93b._.js",
  "static/chunks/_0320351d._.js"
],
    source: "dynamic"
});

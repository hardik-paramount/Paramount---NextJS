(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_7819c29e._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_@apollo_client_ceadac35._.js",
  "static/chunks/node_modules_graphql_8f33e137._.js",
  "static/chunks/node_modules_a4e5a6a5._.js",
  "static/chunks/[root-of-the-server]__2fba93f5._.js"
],
    source: "entry"
});

(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_e58d2b78._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_@apollo_client_dcf859fe._.js",
  "static/chunks/node_modules_graphql_931a79b8._.js",
  "static/chunks/node_modules_5ae04d65._.js",
  "static/chunks/[root-of-the-server]__955e8fe4._.js"
],
    source: "entry"
});

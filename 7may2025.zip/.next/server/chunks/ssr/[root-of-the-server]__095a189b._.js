module.exports = {

"[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("react/jsx-dev-runtime", () => require("react/jsx-dev-runtime"));

module.exports = mod;
}}),
"[externals]/@apollo/client [external] (@apollo/client, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("@apollo/client", () => require("@apollo/client"));

module.exports = mod;
}}),
"[project]/lib/apollo.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@apollo/client [external] (@apollo/client, cjs)");
;
const client = new __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["ApolloClient"]({
    uri: 'http://localhost/wordpress/graphql',
    cache: new __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["InMemoryCache"]()
});
const __TURBOPACK__default__export__ = client;
}}),
"[project]/lib/queries/posts.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// lib/queries/posts.js
__turbopack_context__.s({
    "GET_ALL_POSTS": (()=>GET_ALL_POSTS),
    "GET_PAGINATED_POSTS": (()=>GET_PAGINATED_POSTS),
    "GET_POST_BY_SLUG": (()=>GET_POST_BY_SLUG),
    "GET_PREVIOUS_AND_NEXT_POSTS": (()=>GET_PREVIOUS_AND_NEXT_POSTS)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@apollo/client [external] (@apollo/client, cjs)");
;
const GET_ALL_POSTS = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetAllPosts {
    posts(first: 100) {
      edges {
        node {
          slug
        }
      }
    }
  }
`;
const GET_POST_BY_SLUG = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetPostBySlug($slug: ID!) {
    post(id: $slug, idType: SLUG) {
      title
      content
      slug
      date
      featuredImage {
        node {
          sourceUrl
          altText
        }
      }
      categories {
        nodes {
          name
          slug
        }
      }
      tags {
        nodes {
          name
          slug
        }
      }  
      author {
        node {
          name
        }
      }
    }
  }
`;
const GET_PREVIOUS_AND_NEXT_POSTS = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetPreviousAndNextPosts($slug: String!) {
  previousPost: posts(where: { before: $slug, first: 1 }) {
    edges {
      node {
        title
        slug
      }
    }
  }
  nextPost: posts(where: { after: $slug, first: 1 }) {
    edges {
      node {
        title
        slug
      }
    }
  }
}
`;
const GET_PAGINATED_POSTS = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetPaginatedPosts($offset: Int!, $size: Int!) {
    posts(first: $size, after: $offset) {
      pageInfo {
        hasNextPage
        endCursor
      }
      nodes {
        title
        slug
        excerpt
        date
        featuredImage {
          node {
            sourceUrl
            altText
          }
        }
      }
    }
  }
`;
}}),
"[externals]/react-dom [external] (react-dom, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("react-dom", () => require("react-dom"));

module.exports = mod;
}}),
"[project]/pages/blog/[...slug].js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Post),
    "getStaticPaths": (()=>getStaticPaths),
    "getStaticProps": (()=>getStaticProps)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/apollo.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$posts$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/queries/posts.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [ssr] (ecmascript)");
;
;
;
;
;
function Post({ post, previousPost, nextPost }) {
    if (!post) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
        children: "Post not found"
    }, void 0, false, {
        fileName: "[project]/pages/blog/[...slug].js",
        lineNumber: 9,
        columnNumber: 21
    }, this);
    const { title, content, author, categories = {
        nodes: []
    }, featuredImage, tags = {
        nodes: []
    }, date } = post;
    const publishDate = new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    const imageSrc = featuredImage?.node?.sourceUrl;
    const imageAlt = featuredImage?.node?.altText || title;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("main", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("nav", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        children: "Home"
                    }, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this),
                    " > ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/blog",
                        children: "Blog"
                    }, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 34,
                        columnNumber: 41
                    }, this),
                    " > ",
                    title
                ]
            }, void 0, true, {
                fileName: "[project]/pages/blog/[...slug].js",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            imageSrc && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                src: imageSrc,
                alt: imageAlt,
                width: 1200,
                height: 800,
                layout: "intrinsic" // Allows Next.js to use the image's intrinsic size
            }, void 0, false, {
                fileName: "[project]/pages/blog/[...slug].js",
                lineNumber: 39,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                children: title
            }, void 0, false, {
                fileName: "[project]/pages/blog/[...slug].js",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("strong", {
                        children: "Author:"
                    }, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 52,
                        columnNumber: 9
                    }, this),
                    " ",
                    author?.node?.name || 'Unknown',
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("br", {}, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("strong", {
                        children: "Published:"
                    }, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    " ",
                    publishDate,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("br", {}, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 54,
                        columnNumber: 50
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("strong", {
                        children: "Categories:"
                    }, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this),
                    ' ',
                    categories.nodes.length > 0 ? categories.nodes.map((cat, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                            children: [
                                i > 0 && ', ',
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: `/category/${cat.slug}`,
                                    children: cat.name
                                }, void 0, false, {
                                    fileName: "[project]/pages/blog/[...slug].js",
                                    lineNumber: 60,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, cat.slug, true, {
                            fileName: "[project]/pages/blog/[...slug].js",
                            lineNumber: 58,
                            columnNumber: 13
                        }, this)) : 'Uncategorized',
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("br", {}, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    tags.nodes.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("strong", {
                                children: "Tags:"
                            }, void 0, false, {
                                fileName: "[project]/pages/blog/[...slug].js",
                                lineNumber: 68,
                                columnNumber: 13
                            }, this),
                            ' ',
                            tags.nodes.map((tag, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                    children: [
                                        i > 0 && ', ',
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: `/tag/${tag.slug}`,
                                            children: tag.name
                                        }, void 0, false, {
                                            fileName: "[project]/pages/blog/[...slug].js",
                                            lineNumber: 72,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, tag.slug, true, {
                                    fileName: "[project]/pages/blog/[...slug].js",
                                    lineNumber: 70,
                                    columnNumber: 15
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 67,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/pages/blog/[...slug].js",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                dangerouslySetInnerHTML: {
                    __html: content
                }
            }, void 0, false, {
                fileName: "[project]/pages/blog/[...slug].js",
                lineNumber: 80,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                children: [
                    previousPost && previousPost.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: `/blog/${previousPost.slug}`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                children: [
                                    "Previous Post: ",
                                    previousPost.title
                                ]
                            }, void 0, true, {
                                fileName: "[project]/pages/blog/[...slug].js",
                                lineNumber: 87,
                                columnNumber: 9
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/pages/blog/[...slug].js",
                            lineNumber: 86,
                            columnNumber: 7
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 85,
                        columnNumber: 5
                    }, this),
                    nextPost && nextPost.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: `/blog/${nextPost.slug}`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                children: [
                                    "Next Post: ",
                                    nextPost.title
                                ]
                            }, void 0, true, {
                                fileName: "[project]/pages/blog/[...slug].js",
                                lineNumber: 94,
                                columnNumber: 9
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/pages/blog/[...slug].js",
                            lineNumber: 93,
                            columnNumber: 7
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/pages/blog/[...slug].js",
                        lineNumber: 92,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/pages/blog/[...slug].js",
                lineNumber: 83,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/pages/blog/[...slug].js",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
async function getStaticPaths() {
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].query({
        query: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$posts$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["GET_ALL_POSTS"]
    });
    const paths = res.data.posts.edges.map((edge)=>edge?.node?.slug).filter(Boolean).map((slug)=>({
            params: {
                slug: [
                    slug
                ]
            }
        }));
    // Exclude static paths (like "/services")
    const staticPaths = [
        '/services'
    ]; // Exclude static pages here
    const filteredPaths = paths.filter((pathObj)=>{
        return !staticPaths.includes(`/${pathObj.params.slug[0]}`);
    });
    return {
        //paths: filteredPaths,
        paths,
        fallback: 'blocking'
    };
}
async function getStaticProps({ params }) {
    const slug = params.slug.join('/');
    console.log('Slug from URL:', slug); // Debugging log
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].query({
            query: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$posts$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["GET_POST_BY_SLUG"],
            variables: {
                slug
            }
        });
        if (!data?.post) return {
            notFound: true
        };
        return {
            props: {
                post: data.post
            },
            revalidate: 10
        };
    } catch (error) {
        console.error('Error fetching post:', error);
        return {
            notFound: true
        };
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__095a189b._.js.map
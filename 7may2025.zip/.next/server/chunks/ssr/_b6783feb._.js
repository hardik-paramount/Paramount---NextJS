module.exports = {

"[project]/lib/queries/students.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET_ALL_STUDENTS": (()=>GET_ALL_STUDENTS),
    "GET_STUDENT_BY_SLUG": (()=>GET_STUDENT_BY_SLUG)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@apollo/client [external] (@apollo/client, cjs)");
;
const GET_ALL_STUDENTS = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetAllStudents {
    students {
      nodes {
        id
        title
        slug
        excerpt
      }
    }
  }
`;
const GET_STUDENT_BY_SLUG = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetStudentBySlug($slug: ID!) {
    student(id: $slug, idType: SLUG) {
      title
      content
      featuredImage {
        node {
          sourceUrl
          altText
        }
      }
    }
  }
`;
}}),
"[project]/pages/students/[slug].js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>StudentDetail),
    "getStaticPaths": (()=>getStaticPaths),
    "getStaticProps": (()=>getStaticProps)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/apollo.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$students$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/queries/students.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [ssr] (ecmascript)");
;
;
;
;
function StudentDetail({ student }) {
    if (!student) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
        children: "Student not found"
    }, void 0, false, {
        fileName: "[project]/pages/students/[slug].js",
        lineNumber: 6,
        columnNumber: 24
    }, this);
    const image = student.featuredImage?.node;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("main", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                children: student.title
            }, void 0, false, {
                fileName: "[project]/pages/students/[slug].js",
                lineNumber: 12,
                columnNumber: 7
            }, this),
            image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                src: image.sourceUrl,
                alt: image.altText || student.title,
                width: 800,
                height: 500
            }, void 0, false, {
                fileName: "[project]/pages/students/[slug].js",
                lineNumber: 13,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                dangerouslySetInnerHTML: {
                    __html: student.content
                }
            }, void 0, false, {
                fileName: "[project]/pages/students/[slug].js",
                lineNumber: 14,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/pages/students/[slug].js",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
async function getStaticPaths() {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].query({
        query: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$students$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["GET_ALL_STUDENTS"]
    });
    const paths = data.students.nodes.map((student)=>({
            params: {
                slug: student.slug
            }
        }));
    return {
        paths,
        fallback: 'blocking'
    };
}
async function getStaticProps({ params }) {
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].query({
            query: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$students$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["GET_STUDENT_BY_SLUG"],
            variables: {
                slug: params.slug
            }
        });
        if (!data?.student) return {
            notFound: true
        };
        return {
            props: {
                student: data.student
            },
            revalidate: 10
        };
    } catch (err) {
        return {
            notFound: true
        };
    }
}
}}),

};

//# sourceMappingURL=_b6783feb._.js.map
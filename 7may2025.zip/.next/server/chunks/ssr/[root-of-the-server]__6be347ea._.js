module.exports = {

"[externals]/styled-jsx/style.js [external] (styled-jsx/style.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("styled-jsx/style.js", () => require("styled-jsx/style.js"));

module.exports = mod;
}}),
"[project]/lib/queries/posts.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// lib/queries/posts.js
__turbopack_context__.s({
    "GET_ALL_POSTS": (()=>GET_ALL_POSTS),
    "GET_PAGINATED_POSTS": (()=>GET_PAGINATED_POSTS),
    "GET_POSTS": (()=>GET_POSTS),
    "GET_POSTS_BY_CATEGORY": (()=>GET_POSTS_BY_CATEGORY),
    "GET_POST_BY_SLUG": (()=>GET_POST_BY_SLUG),
    "GET_PREVIOUS_AND_NEXT_POSTS": (()=>GET_PREVIOUS_AND_NEXT_POSTS)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@apollo/client [external] (@apollo/client, cjs)");
;
const GET_ALL_POSTS = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetAllPosts {
    posts(first: 100) {
      edges {
        node {
          slug
        }
      }
    }
  }
`;
const GET_POST_BY_SLUG = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetPostBySlug($slug: ID!) {
    post(id: $slug, idType: SLUG) {
      title
      content
      slug
      date
      featuredImage {
        node {
          sourceUrl
          altText
        }
      }
      categories {
        nodes {
          name
          slug
        }
      }
      tags {
        nodes {
          name
          slug
        }
      }  
      author {
        node {
          name
        }
      }
    }
  }
`;
const GET_PREVIOUS_AND_NEXT_POSTS = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetPreviousAndNextPosts($slug: String!) {
  previousPost: posts(where: { before: $slug, first: 1 }) {
    edges {
      node {
        title
        slug
      }
    }
  }
  nextPost: posts(where: { after: $slug, first: 1 }) {
    edges {
      node {
        title
        slug
      }
    }
  }
}
`;
const GET_PAGINATED_POSTS = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetPaginatedPosts($offset: Int!, $size: Int!) {
    posts(first: $size, after: $offset) {
      pageInfo {
        hasNextPage
        endCursor
      }
      nodes {
        title
        slug
        excerpt
        date
        featuredImage {
          node {
            sourceUrl
            altText
          }
        }
      }
    }
  }
`;
const GET_POSTS_BY_CATEGORY = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetPostsByCategory($slug: ID!) {
    category(id: $slug, idType: SLUG) {
      name
      posts {
        nodes {
          id
          title
          slug
          excerpt
        }
      }
    }
  }
`;
const GET_POSTS = __TURBOPACK__imported__module__$5b$externals$5d2f40$apollo$2f$client__$5b$external$5d$__$2840$apollo$2f$client$2c$__cjs$29$__["gql"]`
  query GetPosts($first: Int!, $after: String) {
  posts(first: $first, after: $after) {
    pageInfo {
      hasNextPage
      endCursor
    }
    nodes {
      id
      slug
      title
      date
      author {
        node {
          name
        }
      }
      featuredImage {
        node {
          sourceUrl
          altText
        }
      }
      categories {
        nodes {
          name
          slug
        }
      }
      tags {
        nodes {
          name
          slug
        }
      }
    }
  }
}

`;
}}),
"[project]/pages/index.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home),
    "getStaticProps": (()=>getStaticProps)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$jsx$2f$style$2e$js__$5b$external$5d$__$28$styled$2d$jsx$2f$style$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/styled-jsx/style.js [external] (styled-jsx/style.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/apollo.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$posts$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/queries/posts.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [ssr] (ecmascript)");
;
;
;
;
;
;
;
function Home({ posts, pageInfo }) {
    const [postList, setPostList] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(posts);
    const [cursor, setCursor] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(pageInfo.endCursor);
    const [hasNext, setHasNext] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(pageInfo.hasNextPage);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const loadMore = async ()=>{
        setLoading(true);
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].query({
            query: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$posts$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["GET_POSTS"],
            variables: {
                first: 9,
                after: cursor
            }
        });
        setPostList([
            ...postList,
            ...res.data.posts.nodes
        ]);
        setCursor(res.data.posts.pageInfo.endCursor);
        setHasNext(res.data.posts.pageInfo.hasNextPage);
        setLoading(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "jsx-533d1a1f49d129b9" + " " + "grid-container",
        children: [
            postList.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "jsx-533d1a1f49d129b9" + " " + "post-card",
                    children: [
                        post.featuredImage?.node?.sourceUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: `/blog/${post.slug}`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: post.featuredImage.node.sourceUrl,
                                alt: post.featuredImage.node.altText || post.title,
                                width: 400,
                                height: 250,
                                className: "post-image"
                            }, void 0, false, {
                                fileName: "[project]/pages/index.js",
                                lineNumber: 36,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/pages/index.js",
                            lineNumber: 35,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                            className: "jsx-533d1a1f49d129b9",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: `/blog/${post.slug}`,
                                children: post.title
                            }, void 0, false, {
                                fileName: "[project]/pages/index.js",
                                lineNumber: 47,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/pages/index.js",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            className: "jsx-533d1a1f49d129b9" + " " + "meta",
                            children: [
                                "By ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("strong", {
                                    className: "jsx-533d1a1f49d129b9",
                                    children: post.author?.node?.name
                                }, void 0, false, {
                                    fileName: "[project]/pages/index.js",
                                    lineNumber: 51,
                                    columnNumber: 16
                                }, this),
                                " on",
                                ' ',
                                new Date(post.date).toLocaleDateString()
                            ]
                        }, void 0, true, {
                            fileName: "[project]/pages/index.js",
                            lineNumber: 50,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "jsx-533d1a1f49d129b9" + " " + "categories",
                            children: post.categories.nodes.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: `/category/${cat.slug}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "jsx-533d1a1f49d129b9" + " " + "category",
                                        children: cat.name
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 58,
                                        columnNumber: 17
                                    }, this)
                                }, cat.slug, false, {
                                    fileName: "[project]/pages/index.js",
                                    lineNumber: 57,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/pages/index.js",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "jsx-533d1a1f49d129b9" + " " + "tags",
                            children: post.tags.nodes.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: `/tag/${tag.slug}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "jsx-533d1a1f49d129b9" + " " + "tag",
                                        children: [
                                            "#",
                                            tag.name
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 66,
                                        columnNumber: 17
                                    }, this)
                                }, tag.slug, false, {
                                    fileName: "[project]/pages/index.js",
                                    lineNumber: 65,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/pages/index.js",
                            lineNumber: 63,
                            columnNumber: 11
                        }, this)
                    ]
                }, post.id, true, {
                    fileName: "[project]/pages/index.js",
                    lineNumber: 33,
                    columnNumber: 9
                }, this)),
            hasNext && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "jsx-533d1a1f49d129b9" + " " + "load-more-wrapper",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                    onClick: loadMore,
                    disabled: loading,
                    className: "jsx-533d1a1f49d129b9",
                    children: loading ? 'Loading...' : 'Load More Posts'
                }, void 0, false, {
                    fileName: "[project]/pages/index.js",
                    lineNumber: 75,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/pages/index.js",
                lineNumber: 74,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$jsx$2f$style$2e$js__$5b$external$5d$__$28$styled$2d$jsx$2f$style$2e$js$2c$__cjs$29$__["default"], {
                id: "533d1a1f49d129b9",
                children: ".grid-container.jsx-533d1a1f49d129b9{grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:2rem;padding:2rem;display:grid}.post-card.jsx-533d1a1f49d129b9{background:#fff;border:1px solid #ddd;border-radius:10px;padding:1rem;box-shadow:0 2px 6px #0000000d}.post-card.jsx-533d1a1f49d129b9 h2.jsx-533d1a1f49d129b9{margin:1rem 0 .5rem;font-size:1.3rem}.meta.jsx-533d1a1f49d129b9{color:#666;margin-bottom:.5rem;font-size:.9rem}.categories.jsx-533d1a1f49d129b9,.tags.jsx-533d1a1f49d129b9{margin-top:.5rem}.category.jsx-533d1a1f49d129b9,.tag.jsx-533d1a1f49d129b9{color:#0070f3;background:#f0f8ff;border-radius:4px;margin-right:.5rem;padding:.2rem .5rem;font-size:.85rem}.post-image.jsx-533d1a1f49d129b9{object-fit:cover;border-radius:8px}.load-more-wrapper.jsx-533d1a1f49d129b9{text-align:center;margin:2rem 0}button.jsx-533d1a1f49d129b9{color:#fff;cursor:pointer;background-color:#0070f3;border:none;border-radius:6px;padding:.75rem 2rem;font-size:1rem}button.jsx-533d1a1f49d129b9:hover{background-color:#005bb5}button.jsx-533d1a1f49d129b9:disabled{cursor:not-allowed;background-color:#ccc}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/pages/index.js",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
async function getStaticProps() {
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apollo$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].query({
        query: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$queries$2f$posts$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["GET_POSTS"],
        variables: {
            first: 6,
            after: null
        }
    });
    return {
        props: {
            posts: res.data.posts.nodes,
            pageInfo: res.data.posts.pageInfo
        },
        revalidate: 60
    };
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__6be347ea._.js.map
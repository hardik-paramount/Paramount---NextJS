globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_next_e58d2b78._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_@apollo_client_dcf859fe._.js",
      "static/chunks/node_modules_graphql_931a79b8._.js",
      "static/chunks/node_modules_5ae04d65._.js",
      "static/chunks/[root-of-the-server]__955e8fe4._.js",
      "static/chunks/pages_index_5771e187._.js",
      "static/chunks/pages_index_c59dd926._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_next_d1cd69cb._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_@apollo_client_dcf859fe._.js",
      "static/chunks/node_modules_graphql_931a79b8._.js",
      "static/chunks/node_modules_react-icons_fi_index_mjs_73949438._.js",
      "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e3f._.js",
      "static/chunks/node_modules_react-icons_lib_75a63dfe._.js",
      "static/chunks/node_modules_5ae04d65._.js",
      "static/chunks/[root-of-the-server]__bb70161c._.js",
      "static/chunks/styles_globals_79636149.css",
      "static/chunks/pages__app_5771e187._.js",
      "static/chunks/pages__app_083a618c._.js"
    ],
    "/blog/[...slug]": [
      "static/chunks/node_modules_next_e58d2b78._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_graphql_332245bf._.js",
      "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e3f._.js",
      "static/chunks/node_modules_react-icons_lib_75a63dfe._.js",
      "static/chunks/node_modules_715de813._.js",
      "static/chunks/[root-of-the-server]__875c0d8f._.js",
      "static/chunks/styles_globals_79636149.css",
      "static/chunks/pages_blog_[___slug]_5771e187.js",
      "static/chunks/pages_blog_[___slug]_160f0b0f.js"
    ],
    "/category/[slug]": [
      "static/chunks/node_modules_next_7819c29e._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__124a0fa7._.js",
      "static/chunks/pages_category_[slug]_5771e187.js",
      "static/chunks/pages_category_[slug]_dfe6a49d.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];
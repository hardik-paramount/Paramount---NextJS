import { useState } from 'react';
import client from '../lib/apollo';
import { GET_POSTS } from '../lib/queries/posts';
import Link from 'next/link';
import Image from 'next/image';

export default function Home({ posts, pageInfo }) {
  const [postList, setPostList] = useState(posts);
  const [cursor, setCursor] = useState(pageInfo.endCursor);
  const [hasNext, setHasNext] = useState(pageInfo.hasNextPage);
  const [loading, setLoading] = useState(false);

  const loadMore = async () => {
    setLoading(true);

    const res = await client.query({
      query: GET_POSTS,
      variables: {
        first: 9,
        after: cursor,
      },
    });

    setPostList([...postList, ...res.data.posts.nodes]);
    setCursor(res.data.posts.pageInfo.endCursor);
    setHasNext(res.data.posts.pageInfo.hasNextPage);
    setLoading(false);
  };

  return (
    <div className="grid-container">
      {postList.map((post) => (
        <div className="post-card" key={post.id}>
          {post.featuredImage?.node?.sourceUrl && (
            <Link href={`/blog/${post.slug}`}>
              <Image
                src={post.featuredImage.node.sourceUrl}
                alt={post.featuredImage.node.altText || post.title}
                width={400}
                height={250}
                className="post-image"
              />
            </Link>
          )}

          <h2>
            <Link href={`/blog/${post.slug}`}>{post.title}</Link>
          </h2>

          <p className="meta">
            By <strong>{post.author?.node?.name}</strong> on{' '}
            {new Date(post.date).toLocaleDateString()}
          </p>

          <div className="categories">
            {post.categories.nodes.map((cat) => (
              <Link key={cat.slug} href={`/category/${cat.slug}`}>
                <span className="category">{cat.name}</span>
              </Link>
            ))}
          </div>

          <div className="tags">
            {post.tags.nodes.map((tag) => (
              <Link key={tag.slug} href={`/tag/${tag.slug}`}>
                <span className="tag">#{tag.name}</span>
              </Link>
            ))}
          </div>
        </div>
      ))}

      {hasNext && (
        <div className="load-more-wrapper">
          <button onClick={loadMore} disabled={loading}>
            {loading ? 'Loading...' : 'Load More Posts'}
          </button>
        </div>
      )}

      <style jsx>{`
        .grid-container {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: 2rem;
          padding: 2rem;
        }
        .post-card {
          border: 1px solid #ddd;
          border-radius: 10px;
          padding: 1rem;
          background: white;
          box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .post-card h2 {
          font-size: 1.3rem;
          margin: 1rem 0 0.5rem;
        }
        .meta {
          font-size: 0.9rem;
          color: #666;
          margin-bottom: 0.5rem;
        }
        .categories, .tags {
          margin-top: 0.5rem;
        }
        .category, .tag {
          margin-right: 0.5rem;
          font-size: 0.85rem;
          color: #0070f3;
          background: #f0f8ff;
          padding: 0.2rem 0.5rem;
          border-radius: 4px;
        }
        .post-image {
          border-radius: 8px;
          object-fit: cover;
        }
        .load-more-wrapper {
          text-align: center;
          margin: 2rem 0;
        }
        button {
          padding: 0.75rem 2rem;
          font-size: 1rem;
          background-color: #0070f3;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
        }
        button:hover {
          background-color: #005bb5;
        }
        button:disabled {
          background-color: #ccc;
          cursor: not-allowed;
        }
      `}</style>
    </div>
  );
}

export async function getStaticProps() {
  const res = await client.query({
    query: GET_POSTS,
    variables: {
      first: 6,
      after: null,
    },
  });

  return {
    props: {
      posts: res.data.posts.nodes,
      pageInfo: res.data.posts.pageInfo,
    },
    revalidate: 60,
  };
}

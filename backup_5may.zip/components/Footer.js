// components/Footer.js
import Link from 'next/link';
import '../styles/globals.css'; // if you're using CSS Modules, rename to Footer.module.css

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-logo">Paramount</div>

      <nav className="footer-menu">
        <p>Assign Footer Menu</p>
      </nav>

      <div className="footer-content">
        NewsBlogger - Magazine & Blog{' '}
        <a href="https://wordpress.org" target="_blank" rel="noopener noreferrer">WordPress</a>{' '}
        Theme 2025 | Powered By{' '}
        <a href="https://spicethemes.com" target="_blank" rel="noopener noreferrer">SpiceThemes</a>
      </div>
    </footer>
  );
}

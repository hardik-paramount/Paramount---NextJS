import client from '../../lib/apollo';
import { GET_ALL_POSTS, GET_POST_BY_SLUG, GET_PREVIOUS_AND_NEXT_POSTS } from '../../lib/queries/posts';
import Link from 'next/link';
import Image from 'next/image';
//import '../../styles/style.css'; // Import global styles
import '../../styles/globals.css'

export default function Post({ post, previousPost, nextPost }) {
  if (!post) return <p className="post-not-found">Post not found</p>;

  const {
    title,
    content,
    author,
    categories = { nodes: [] },
    featuredImage,
    tags = { nodes: [] },
    date,
  } = post;

  const publishDate = new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const imageSrc = featuredImage?.node?.sourceUrl;
  const imageAlt = featuredImage?.node?.altText || title;

  return (
    <main className="post-container">
      {/* Breadcrumb */}
      {/* <nav className="breadcrumb">
        <Link href="/">Home</Link> &gt; <Link href="/blog">Blog</Link> &gt; <span>{title}</span>
      </nav> */}

      {/* Featured Image */}
      {imageSrc && (
        <div className="featured-image">
          <Image
            src={imageSrc}
            alt={imageAlt}
            width={1200}
            height={800}
            layout="intrinsic"
          />
        </div>
      )}

      {/* Title */}
      <h1 className="post-title">{title}</h1>

      {/* Meta Info */}
      <div className="post-meta">
        <p><strong>Author:</strong> {author?.node?.name || 'Unknown'}</p>
        <p><strong>Published:</strong> {publishDate}</p>
        <p><strong>Categories:</strong>{' '}
          {categories.nodes.length > 0
            ? categories.nodes.map((cat, i) => (
              <span key={cat.slug}>
                {i > 0 && ', '}
                <Link href={`/category/${cat.slug}`}>{cat.name}</Link>
              </span>
            ))
            : 'Uncategorized'}
        </p>
        {tags.nodes.length > 0 && (
          <p><strong>Tags:</strong>{' '}
            {tags.nodes.map((tag, i) => (
              <span key={tag.slug}>
                {i > 0 && ', '}
                <Link href={`/tag/${tag.slug}`}>{tag.name}</Link>
              </span>
            ))}
          </p>
        )}
      </div>

      {/* Content */}
      <div className="post-content" dangerouslySetInnerHTML={{ __html: content }} />

      {/* Previous and Next Post Links */}
      <div className="post-navigation">
        {previousPost?.title && (
          <div className="previous-post">
            <Link href={`/blog/${previousPost.slug}`}>← {previousPost.title}</Link>
          </div>
        )}
        {nextPost?.title && (
          <div className="next-post">
            <Link href={`/blog/${nextPost.slug}`}>{nextPost.title} →</Link>
          </div>
        )}
      </div>
    </main>
  );
}


export async function getStaticPaths() {
  const res = await client.query({
    query: GET_ALL_POSTS, // Replace with your actual query
  });

  const paths = res.data.posts.edges
    .map((edge) => edge?.node?.slug)
    .filter(Boolean)
    .map((slug) => ({
      params: { slug: [slug] },
    }));

  // Exclude static paths (like "/services")
  const staticPaths = ['/services']; // Exclude static pages here
  const filteredPaths = paths.filter((pathObj) => {
    return !staticPaths.includes(`/${pathObj.params.slug[0]}`);
  });

  return {
    //paths: filteredPaths,
    paths,
    fallback: 'blocking',
  };
}

export async function getStaticProps({ params }) {
  const slug = params.slug.join('/');
  console.log('Slug from URL:', slug);  // Debugging log
  
  try {
    const { data } = await client.query({
      query: GET_POST_BY_SLUG,
      variables: { slug },
    });
    
    if (!data?.post) return { notFound: true };
    
    return {
      props: { post: data.post },
      revalidate: 10,
    };
  } catch (error) {
    console.error('Error fetching post:', error);
    return { notFound: true };
  }
}
